# Figure 4 independent normalized-duration audit

This run independently reconstructs the Figure 4 component analysis from CEMHSEY MAT recordings.
Each of the ten participants contributes a median over Days 2-11; inference uses N=10, not 100 independent observations.
The pipeline does not modify any manuscript numbers.

- Alpha=0 count: 12/20; manuscript reports 12/20.
- Supplementary parameter sets matching individually: 19/20.
- Cohort contrast medians within 0.001: 6/6.
- CI bounds within 0.01: 6/6.
- Historical code was not used; any small mismatch reflects a separately specified analysis and should be investigated.
- Check supplementary_parameters_comparison.csv for alpha and process-noise-scale discrepancies.

## Comparison with the manuscript

                         contrast  k  expected_delta  observed_delta  abs_delta_error  expected_ci_low  observed_ci_low  expected_ci_high  observed_ci_high  expected_p_holm  observed_p_holm  median_within_0.001  both_ci_bounds_within_0.01
                  stage_alignment  8        0.081697        0.081675     2.200727e-05         0.011109         0.011117          0.230108          0.230281           0.0390         0.039062                 True                        True
                  stage_alignment 16        0.068871        0.068899     2.774015e-05         0.016384         0.016394          0.199991          0.199921           0.0390         0.039062                 True                        True
     stage_temporal_fixed_weights  8        0.009632        0.009618     1.410098e-05         0.007770         0.007767          0.022737          0.022739           0.0117         0.011719                 True                        True
     stage_temporal_fixed_weights 16        0.011658        0.011659     5.658316e-07         0.006221         0.006214          0.019429          0.019420           0.0117         0.011719                 True                        True
stage_adaptive_variance_matched_q  8        0.000000        0.000000     0.000000e+00         0.000000         0.000000          0.008986          0.007045           0.2500         0.250000                 True                        True
stage_adaptive_variance_matched_q 16        0.000000        0.000000     0.000000e+00         0.000000         0.000000          0.006460          0.006458           0.2500         0.250000                 True                        True

## Subject 6

 k  unaligned  aligned    delta  reported_unaligned  reported_aligned  within_0.02
 8  -2.440469 0.904598 3.345067              -2.440             0.905         True
16  -3.039977 0.909960 3.949937              -3.041             0.910         True

## Next decision

If any comparisons fail, inspect the per-participant deltas and report discrepancies explicitly; do not tune the implementation to published summaries.
If all pass, Figure 4 has independent empirical support and its archive can be updated with these outputs.
